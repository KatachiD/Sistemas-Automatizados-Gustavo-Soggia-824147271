#include <DHT.h>
#define DHTPIN 4
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);
const int BTN = 2;
const int LED = 8;
void setup() {
Serial.begin(9600);
dht.begin();
pinMode(BTN, INPUT_PULLUP);
pinMode(LED, OUTPUT);
}
void loop() {
float t = dht.readTemperature();
if (isnan(t)) {
Serial.println("FALHA DE SENSOR");
} else {
Serial.println(t);
}
delay(1000);

int bruto = analogRead(A0);
if (bruto < 400) {
Serial.println("NORMAL");
} else if (bruto < 750) {
Serial.println("ATENCAO");
} else {
Serial.println("ALARME");
}

bool ativo = digitalRead(BTN) == LOW;
digitalWrite(LED, ativo ? HIGH : LOW);
}